from teme.teme import get_token
from teme.teme import send_message
